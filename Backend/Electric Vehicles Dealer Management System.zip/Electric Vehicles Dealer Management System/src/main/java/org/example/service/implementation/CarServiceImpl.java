package org.example.service.implementation;

import org.example.dto.CarResponse;
import org.example.entity.DealerCar;
import org.example.entity.UserAccount;
import org.example.repository.DealerCarRepository;
import org.example.repository.UserAccountRepository;
import org.example.service.CarService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class CarServiceImpl implements CarService {

    @Autowired
    private DealerCarRepository dealerCarRepository;

    @Autowired
    private UserAccountRepository userAccountRepository;

    @Override
    public List<CarResponse> getAllCarsByCurrentDealer(String email) {
        // Tìm user account với dealer thông tin theo email
        UserAccount userAccount = userAccountRepository.findByEmailWithDealer(email)
                .orElseThrow(() -> new RuntimeException("User not found or not associated with any dealer"));

        if (userAccount.getDealer() == null) {
            throw new RuntimeException("User is not associated with any dealer");
        }

        // Lấy tất cả xe của dealer
        List<DealerCar> dealerCars = dealerCarRepository.findDealerCarsByDealerId(userAccount.getDealer().getDealerId());

        // Convert sang DTO
        return dealerCars.stream()
                .map(this::convertToCarResponse)
                .collect(Collectors.toList());
    }

    private CarResponse convertToCarResponse(DealerCar dealerCar) {
        return CarResponse.builder()
                .carId(dealerCar.getCar().getCarId())
                .modelName(dealerCar.getCar().getCarVariant().getCarModel().getModelName())
                .variantName(dealerCar.getCar().getCarVariant().getVariantName())
                .configurationName(dealerCar.getCar().getCarVariant().getConfiguration() != null ?
                    "Battery: " + dealerCar.getCar().getCarVariant().getConfiguration().getBatteryCapacity() +
                    " - Range: " + dealerCar.getCar().getCarVariant().getConfiguration().getRangeKm() + "km" : null)
                .availableColors(dealerCar.getCar().getColor() != null ?
                    java.util.Collections.singletonList(dealerCar.getCar().getColor().getColor_name()) :
                    java.util.Collections.emptyList())
                .productionYear(dealerCar.getCar().getProductionYear())
                .price(dealerCar.getCar().getPrice())
                .status(dealerCar.getCar().getStatus())
                .quantity(dealerCar.getQuantity())
                .build();
    }
}
