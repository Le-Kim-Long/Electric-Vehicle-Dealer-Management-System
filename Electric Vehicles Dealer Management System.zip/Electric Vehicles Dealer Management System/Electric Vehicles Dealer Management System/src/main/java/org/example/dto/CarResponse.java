package org.example.dto;

import lombok.*;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CarResponse {
    private Integer carId;
    private String modelName;
    private String variantName;
    private String configurationName;
    private List<String> availableColors;
    private Integer productionYear;
    private Long price;
    private String status;
    private Integer quantity;
}
