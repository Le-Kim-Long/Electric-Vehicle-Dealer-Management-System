package org.example.service.implementation;

import org.example.dto.CarResponse;
import org.example.entity.Car;
import org.example.entity.DealerCar;
import org.example.entity.UserAccount;
import org.example.repository.CarRepository;
import org.example.repository.DealerCarRepository;
import org.example.repository.UserAccountRepository;
import org.example.service.CarService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class CarServiceImpl implements CarService {

    @Autowired
    private DealerCarRepository dealerCarRepository;

    @Autowired
    private UserAccountRepository userAccountRepository;

    @Autowired
    private CarRepository carRepository;

    @Override
    public List<CarResponse> getAllCarsByCurrentDealer(String email) {
        // Tìm user account với dealer thông tin theo email
        UserAccount userAccount = userAccountRepository.findByEmailWithDealer(email)
                .orElseThrow(() -> new RuntimeException("User not found or not associated with any dealer"));

        if (userAccount.getDealer() == null) {
            throw new RuntimeException("User is not associated with any dealer");
        }

        // Lấy tất cả xe của dealer
        List<DealerCar> dealerCars = dealerCarRepository.findDealerCarsByDealerId(userAccount.getDealer().getDealerId());

        // Convert sang DTO
        return dealerCars.stream()
                .map(this::convertToCarResponse)
                .collect(Collectors.toList());
    }

    @Override
    public List<CarResponse> searchCarsByVariantOrModelName(String email, String searchTerm) {
        // Tìm user account với dealer thông tin theo email
        UserAccount userAccount = userAccountRepository.findByEmailWithDealer(email)
                .orElseThrow(() -> new RuntimeException("User not found or not associated with any dealer"));

        if (userAccount.getDealer() == null) {
            throw new RuntimeException("User is not associated with any dealer");
        }

        // Xử lý tìm kiếm linh động
        List<Car> cars = performFlexibleSearch(userAccount.getDealer().getDealerId(), searchTerm);

        // Convert sang DTO
        return cars.stream()
                .map(this::convertToCarResponseFromCar)
                .collect(Collectors.toList());
    }

    @Override
    public List<CarResponse> searchCarsByPriceRange(String email, Double minPrice, Double maxPrice) {
        // Tìm user account với dealer thông tin theo email
        UserAccount userAccount = userAccountRepository.findByEmailWithDealer(email)
                .orElseThrow(() -> new RuntimeException("User not found or not associated with any dealer"));

        if (userAccount.getDealer() == null) {
            throw new RuntimeException("User is not associated with any dealer");
        }

        // Validate price range
        if (minPrice < 0 || maxPrice < 0) {
            throw new RuntimeException("Price values cannot be negative");
        }

        if (minPrice > maxPrice) {
            throw new RuntimeException("Minimum price cannot be greater than maximum price");
        }

        // Tìm kiếm xe theo khoảng giá
        List<Car> cars = carRepository.findCarsByDealerIdAndPriceRange(
            userAccount.getDealer().getDealerId(),
            minPrice,
            maxPrice
        );

        // Convert sang DTO
        return cars.stream()
                .map(this::convertToCarResponseFromCar)
                .collect(Collectors.toList());
    }

    private List<Car> performFlexibleSearch(Integer dealerId, String searchTerm) {
        // Chuẩn hóa search term
        String normalizedSearchTerm = normalizeSearchTerm(searchTerm);

        // Tách searchTerm thành các từ khóa riêng biệt
        String[] keywords = normalizedSearchTerm.toLowerCase().trim().split("\\s+");

        // Trước tiên thử tìm kiếm với toàn bộ chuỗi gốc
        List<Car> exactResults = carRepository.searchCarsByVariantOrModelName(dealerId, searchTerm);

        if (!exactResults.isEmpty()) {
            return exactResults;
        }

        // Thử tìm kiếm với chuỗi đã chuẩn hóa
        if (!normalizedSearchTerm.equals(searchTerm)) {
            List<Car> normalizedResults = carRepository.searchCarsByVariantOrModelName(dealerId, normalizedSearchTerm);
            if (!normalizedResults.isEmpty()) {
                return normalizedResults;
            }
        }

        // Tìm kiếm với substring (không có khoảng trắng)
        List<Car> substringResults = searchBySubstrings(dealerId, searchTerm.toLowerCase());
        if (!substringResults.isEmpty()) {
            return filterByKeywordRelevance(substringResults, keywords, searchTerm.toLowerCase());
        }

        // Nếu vẫn không tìm thấy, thử tìm kiếm với từng từ khóa riêng biệt
        Set<Car> combinedResults = new LinkedHashSet<>();

        for (String keyword : keywords) {
            if (keyword.length() >= 2) { // Chỉ tìm kiếm từ khóa có ít nhất 2 ký tự
                List<Car> keywordResults = carRepository.searchCarsByVariantOrModelName(dealerId, keyword);
                combinedResults.addAll(keywordResults);
            }
        }

        // Lọc kết quả để chỉ giữ lại những xe có chứa nhiều từ khóa nhất
        return filterByKeywordRelevance(new ArrayList<>(combinedResults), keywords, searchTerm.toLowerCase());
    }

    private String normalizeSearchTerm(String searchTerm) {
        if (searchTerm == null || searchTerm.trim().isEmpty()) {
            return searchTerm;
        }

        String normalized = searchTerm.toLowerCase().trim();

        // Thêm khoảng trắng giữa chữ và số
        // Ví dụ: "vf3eco" -> "vf3 eco", "vf8plus" -> "vf8 plus"
        normalized = normalized.replaceAll("([a-zA-Z]+)(\\d+)", "$1 $2"); // chữ + số
        normalized = normalized.replaceAll("(\\d+)([a-zA-Z]+)", "$1 $2"); // số + chữ

        // Xử lý các từ phổ biến trong tên xe
        normalized = normalized.replaceAll("(vf\\d+)(eco|plus|standard|premium|luxury)", "$1 $2");
        normalized = normalized.replaceAll("(vinfast)(\\w+)", "$1 $2");

        // Loại bỏ khoảng trắng thừa
        normalized = normalized.replaceAll("\\s+", " ").trim();

        return normalized;
    }

    private List<Car> searchBySubstrings(Integer dealerId, String searchTerm) {
        List<Car> allCars = carRepository.findCarsByDealerId(dealerId);
        List<Car> matchingCars = new ArrayList<>();

        for (Car car : allCars) {
            String modelName = car.getCarVariant().getCarModel().getModelName().toLowerCase();
            String variantName = car.getCarVariant().getVariantName().toLowerCase();
            String fullName = (modelName + variantName).replaceAll("\\s+", "");
            String fullNameWithSpace = (modelName + " " + variantName).toLowerCase();

            // Kiểm tra substring match - chỉ thêm nếu có match thực sự
            boolean hasMatch = false;

            if (fullName.contains(searchTerm) && searchTerm.length() >= 3) {
                hasMatch = true;
            } else if (fullNameWithSpace.contains(searchTerm) && searchTerm.length() >= 3) {
                hasMatch = true;
            } else if (modelName.replaceAll("\\s+", "").contains(searchTerm) && searchTerm.length() >= 2) {
                hasMatch = true;
            } else if (variantName.replaceAll("\\s+", "").contains(searchTerm) && searchTerm.length() >= 2) {
                hasMatch = true;
            }

            if (hasMatch) {
                matchingCars.add(car);
            }
        }

        return matchingCars;
    }

    private List<Car> filterByKeywordRelevance(List<Car> cars, String[] keywords, String originalSearchTerm) {
        // Tính điểm relevance cho mỗi xe
        return cars.stream()
                .map(car -> new CarWithScore(car, calculateRelevanceScore(car, keywords, originalSearchTerm)))
                .filter(carWithScore -> carWithScore.score > 0)
                .sorted((a, b) -> Integer.compare(b.score, a.score)) // Sắp xếp theo điểm giảm dần
                .map(carWithScore -> carWithScore.car)
                .collect(Collectors.toList());
    }

    private int calculateRelevanceScore(Car car, String[] keywords, String originalSearchTerm) {
        int score = 0;
        String modelName = car.getCarVariant().getCarModel().getModelName().toLowerCase();
        String variantName = car.getCarVariant().getVariantName().toLowerCase();
        String fullName = (modelName + " " + variantName).toLowerCase();
        String fullNameNoSpace = (modelName + variantName).replaceAll("\\s+", "");

        // Kiểm tra match chính xác với search term gốc
        if (fullNameNoSpace.contains(originalSearchTerm) ||
                fullName.contains(originalSearchTerm) ||
                modelName.replaceAll("\\s+", "").contains(originalSearchTerm) ||
                variantName.replaceAll("\\s+", "").contains(originalSearchTerm)) {
            score += 10; // Điểm cao cho match chính xác
        }

        // Kiểm tra match với từng keyword
        for (String keyword : keywords) {
            String lowerKeyword = keyword.toLowerCase();
            if (modelName.contains(lowerKeyword) || variantName.contains(lowerKeyword)) {
                score += 2;
            }
            // Thưởng điểm nếu tìm thấy từ khóa trong tên đầy đủ
            if (fullName.contains(lowerKeyword)) {
                score++;
            }
        }

        return score;
    }

    private CarResponse convertToCarResponse(DealerCar dealerCar) {
        return CarResponse.builder()
                .carId(dealerCar.getCar().getCarId())
                .modelName(dealerCar.getCar().getCarVariant().getCarModel().getModelName())
                .variantName(dealerCar.getCar().getCarVariant().getVariantName())
                .configurationName(dealerCar.getCar().getCarVariant().getConfiguration() != null ?
                    "Battery: " + dealerCar.getCar().getCarVariant().getConfiguration().getBatteryCapacity() +
                    " - Range: " + dealerCar.getCar().getCarVariant().getConfiguration().getRangeKm() + "km" : null)
                .availableColors(dealerCar.getCar().getColor() != null ?
                    java.util.Collections.singletonList(dealerCar.getCar().getColor().getColor_name()) :
                    java.util.Collections.emptyList())
                .productionYear(dealerCar.getCar().getProductionYear())
                .price(dealerCar.getCar().getPrice())
                .status(dealerCar.getCar().getStatus())
                .quantity(dealerCar.getQuantity())
                .build();
    }

    private CarResponse convertToCarResponseFromCar(Car car) {
        // Tìm quantity từ DealerCar
        Integer quantity = 0;
        if (car.getDealerCars() != null && !car.getDealerCars().isEmpty()) {
            quantity = car.getDealerCars().stream()
                    .mapToInt(DealerCar::getQuantity)
                    .sum();
        }

        return CarResponse.builder()
                .carId(car.getCarId())
                .modelName(car.getCarVariant().getCarModel().getModelName())
                .variantName(car.getCarVariant().getVariantName())
                .configurationName(car.getCarVariant().getConfiguration() != null ?
                    "Battery: " + car.getCarVariant().getConfiguration().getBatteryCapacity() +
                    " - Range: " + car.getCarVariant().getConfiguration().getRangeKm() + "km" : null)
                .availableColors(car.getColor() != null ?
                    java.util.Collections.singletonList(car.getColor().getColor_name()) :
                    java.util.Collections.emptyList())
                .productionYear(car.getProductionYear())
                .price(car.getPrice())
                .status(car.getStatus())
                .quantity(quantity)
                .build();
    }

    // Inner class để lưu trữ car với điểm số
    private static class CarWithScore {
        final Car car;
        final int score;

        CarWithScore(Car car, int score) {
            this.car = car;
            this.score = score;
        }
    }
}
