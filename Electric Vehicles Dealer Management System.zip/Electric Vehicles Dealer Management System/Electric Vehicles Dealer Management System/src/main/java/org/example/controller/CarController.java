package org.example.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.example.dto.CarResponse;
import org.example.service.CarService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/cars")
@Tag(name = "Car Management", description = "APIs for managing cars by dealer")
public class CarController {

    @Autowired
    private CarService carService;

    @GetMapping("/all-cars-by-dealer")
    @Operation(
        summary = "Get all cars by current dealer",
        description = "Returns all cars that belong to the dealer of the currently authenticated user. Requires JWT token in Authorization header."
    )
    @SecurityRequirement(name = "Bearer Authentication")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successfully retrieved cars"),
        @ApiResponse(responseCode = "401", description = "Unauthorized - Invalid or missing JWT token"),
        @ApiResponse(responseCode = "400", description = "Bad request - User not associated with any dealer"),
        @ApiResponse(responseCode = "500", description = "Internal server error")
    })
    public ResponseEntity<?> getCarsByCurrentDealer() {
        try {
            // Lấy authentication từ SecurityContext
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

            if (authentication == null || !authentication.isAuthenticated()) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body("Authorization header is required. Please login first to get JWT token.");
            }

            // Lấy email từ authentication (JWT subject)
            String email = authentication.getName();

            if (email == null || email.isEmpty()) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body("Invalid authentication. Please login again.");
            }

            List<CarResponse> cars = carService.getAllCarsByCurrentDealer(email);

            return ResponseEntity.ok(cars);

        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body("An error occurred while fetching cars: " + e.getMessage());
        }
    }

    @GetMapping("/search")
    @Operation(
        summary = "Search cars by variant name or model name (flexible search)",
        description = "Returns cars that belong to the current dealer and match the search criteria. " +
                     "Supports flexible search with multiple keywords (e.g., 'vf3 eco', 'vinfast plus'). " +
                     "The API will search for matches in both model name and variant name, and rank results by relevance. " +
                     "Requires JWT token in Authorization header."
    )
    @SecurityRequirement(name = "Bearer Authentication")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successfully retrieved cars (sorted by relevance)"),
        @ApiResponse(responseCode = "401", description = "Unauthorized - Invalid or missing JWT token"),
        @ApiResponse(responseCode = "400", description = "Bad request - User not associated with any dealer or invalid search term"),
        @ApiResponse(responseCode = "500", description = "Internal server error")
    })
    public ResponseEntity<?> searchCars(@RequestParam(value = "searchTerm", required = true) String searchTerm) {
        try {
            // Kiểm tra search term không rỗng
            if (searchTerm == null || searchTerm.trim().isEmpty()) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("Search term cannot be empty");
            }

            // Lấy authentication từ SecurityContext
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

            if (authentication == null || !authentication.isAuthenticated()) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body("Authorization header is required. Please login first to get JWT token.");
            }

            // Lấy email từ authentication (JWT subject)
            String email = authentication.getName();

            if (email == null || email.isEmpty()) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body("Invalid authentication. Please login again.");
            }

            List<CarResponse> cars = carService.searchCarsByVariantOrModelName(email, searchTerm.trim());

            return ResponseEntity.ok(cars);

        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body("An error occurred while searching cars: " + e.getMessage());
        }
    }

    @GetMapping("/search-by-price")
    @Operation(
        summary = "Search cars by price range",
        description = "Returns cars that belong to the current dealer and fall within the specified price range (in VND). " +
                     "Price values should be in millions (e.g., 500 for 500 triệu VND). " +
                     "Requires JWT token in Authorization header."
    )
    @SecurityRequirement(name = "Bearer Authentication")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successfully retrieved cars within price range"),
        @ApiResponse(responseCode = "401", description = "Unauthorized - Invalid or missing JWT token"),
        @ApiResponse(responseCode = "400", description = "Bad request - Invalid price range or user not associated with any dealer"),
        @ApiResponse(responseCode = "500", description = "Internal server error")
    })
    public ResponseEntity<?> searchCarsByPriceRange(
            @RequestParam(value = "minPrice", required = true) Double minPrice,
            @RequestParam(value = "maxPrice", required = true) Double maxPrice) {
        try {
            // Kiểm tra giá trị hợp lệ
            if (minPrice == null || maxPrice == null) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("Both minPrice and maxPrice are required");
            }

            if (minPrice < 0 || maxPrice < 0) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("Price values cannot be negative");
            }

            if (minPrice > maxPrice) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("Minimum price cannot be greater than maximum price");
            }

            // Lấy authentication từ SecurityContext
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

            if (authentication == null || !authentication.isAuthenticated()) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body("Authorization header is required. Please login first to get JWT token.");
            }

            // Lấy email từ authentication (JWT subject)
            String email = authentication.getName();

            if (email == null || email.isEmpty()) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body("Invalid authentication. Please login again.");
            }

            // Chuyển đổi từ triệu VND sang VND (nhân với 1,000,000)
            Double minPriceVND = minPrice * 1_000_000;
            Double maxPriceVND = maxPrice * 1_000_000;

            List<CarResponse> cars = carService.searchCarsByPriceRange(email, minPriceVND, maxPriceVND);

            return ResponseEntity.ok(cars);

        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body("An error occurred while searching cars by price range: " + e.getMessage());
        }
    }
}
